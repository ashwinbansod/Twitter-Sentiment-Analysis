It requires the basic setup as discussed on the piazza.
It needs complete nltk library.
use nltk.download() to download complete nltk corpus.